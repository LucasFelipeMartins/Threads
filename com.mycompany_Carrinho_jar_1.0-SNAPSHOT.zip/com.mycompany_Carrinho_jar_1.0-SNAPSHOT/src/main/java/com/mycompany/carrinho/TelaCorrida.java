import javax.swing.*;
import java.awt.*;
import java.util.List;

public class TelaCorrida extends JFrame {

    private final PainelPista painelPista;
    private final JLabel lblStatus;
    private final JButton btnIniciar;
    private GerenciadorCorrida gerenciadorAtual;

    public TelaCorrida() {
        setTitle("Simulador de Corrida Multithread");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Cabeçalho
        JPanel painelTopo = new JPanel(new BorderLayout());
        painelTopo.setBorder(BorderFactory.createEmptyBorder(10, 15, 5, 15));
        lblStatus = new JLabel("Pronto para iniciar a corrida!");
        lblStatus.setFont(new Font("SansSerif", Font.BOLD, 14));
        painelTopo.add(lblStatus, BorderLayout.WEST);

        btnIniciar = new JButton("Iniciar Corrida");
        btnIniciar.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnIniciar.addActionListener(e -> iniciarNovaCorrida());
        painelTopo.add(btnIniciar, BorderLayout.EAST);

        add(painelTopo, BorderLayout.NORTH);

        // Pista central
        painelPista = new PainelPista();
        add(painelPista, BorderLayout.CENTER);

        // Legenda inferior
        JLabel lblLegenda = new JLabel("Prioridades: Carro 1 = MIN (80ms) | Carro 2 = MED (50ms) | Carro 3 = MAX (20ms)", SwingConstants.CENTER);
        lblLegenda.setBorder(BorderFactory.createEmptyBorder(5, 10, 10, 10));
        add(lblLegenda, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null); // Centraliza na tela
    }

    private void iniciarNovaCorrida() {
        btnIniciar.setEnabled(false);
        lblStatus.setText("Corrida em andamento... Iteração: 0");

        LogCorrida log = new LogCorrida(ConfiguracaoCorrida.ARQUIVO_LOG);
        gerenciadorAtual = new GerenciadorCorrida(ConfiguracaoCorrida.TAMANHO_PISTA, log, this);

        Corredor c1 = new Corredor(1, "MIN", Thread.MIN_PRIORITY, 80, gerenciadorAtual);
        Corredor c2 = new Corredor(2, "MED", Thread.NORM_PRIORITY, 50, gerenciadorAtual);
        Corredor c3 = new Corredor(3, "MAX", Thread.MAX_PRIORITY, 20, gerenciadorAtual);

        gerenciadorAtual.registrarCorredor(c1);
        gerenciadorAtual.registrarCorredor(c2);
        gerenciadorAtual.registrarCorredor(c3);

        painelPista.setDadosCorrida(gerenciadorAtual.getCorredores(), ConfiguracaoCorrida.TAMANHO_PISTA);

        // Thread coordenadora para não travar a interface gráfica com o .join()
        new Thread(() -> {
            c1.start();
            c2.start();
            c3.start();

            try {
                c1.join();
                c2.join();
                c3.join();
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
            }

            gerenciadorAtual.finalizar();
        }).start();
    }

    public void atualizarPista(int iteracao) {
        lblStatus.setText("Corrida em andamento... Iteração: " + iteracao);
        painelPista.repaint();
    }

    public void exibirPodio(List<Corredor> podio) {
        lblStatus.setText("Corrida Finalizada! Log salvo em " + ConfiguracaoCorrida.ARQUIVO_LOG);
        btnIniciar.setText("Correr Novamente");
        btnIniciar.setEnabled(true);

        StringBuilder sb = new StringBuilder("Classificação Final:\n\n");
        for (int i = 0; i < podio.size(); i++) {
            Corredor c = podio.get(i);
            sb.append(String.format("%dº Lugar: Carro #%d [%s] (Prioridade: %d)\n",
                    (i + 1), c.getIdCorredor(), c.getRotulo(), c.getPriority()));
        }

        JOptionPane.showMessageDialog(this, sb.toString(), "Pódio da Corrida", JOptionPane.INFORMATION_MESSAGE);
    }
}