import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TelaCorrida tela = new TelaCorrida();
            tela.setVisible(true);
        });
    }
}