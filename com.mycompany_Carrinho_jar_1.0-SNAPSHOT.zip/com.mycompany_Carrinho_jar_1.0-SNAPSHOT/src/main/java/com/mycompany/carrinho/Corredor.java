package com.mycompany.carrinho;

public class Corredor extends Thread {

    private final int idCorredor;
    private final String rotulo;
    private final int delayMs;
    private final GerenciadorCorrida gerenciador;
    private volatile int posicao = 0;

    public Corredor(int idCorredor, String rotulo, int prioridade, int delayMs, GerenciadorCorrida gerenciador) {
        super("Thread-Corredor-" + idCorredor + "-" + rotulo);
        this.idCorredor = idCorredor;
        this.rotulo = rotulo;
        this.delayMs = delayMs;
        this.gerenciador = gerenciador;
        this.setPriority(prioridade);
    }

    public int getIdCorredor() {
        return idCorredor;
    }

    public String getRotulo() {
        return rotulo;
    }

    public int getPosicao() {
        return posicao;
    }

    @Override
    public void run() {
        int limitePista = gerenciador.getTamanhoPista();

        while (this.posicao < limitePista && !Thread.currentThread().isInterrupted()) {
            this.posicao++;
            gerenciador.registrarPasso();

            if (this.posicao >= limitePista) {
                break;
            }

            try {
                Thread.sleep(this.delayMs);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }

        gerenciador.registrarChegada(this);
    }
}