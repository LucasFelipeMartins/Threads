package com.mycompany.carrinho;

import javax.swing.SwingUtilities;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GerenciadorCorrida {

    private final int tamanhoPista;
    private final LogCorrida logCorrida;
    private final AnimacaoCorrida tela;
    private final List<Corredor> corredores = new ArrayList<>();
    private final List<Corredor> podio = Collections.synchronizedList(new ArrayList<>());

    private int iteracao = 0;

    public GerenciadorCorrida(int tamanhoPista, LogCorrida logCorrida, AnimacaoCorrida tela) {
        this.tamanhoPista = tamanhoPista;
        this.logCorrida = logCorrida;
        this.tela = tela;
    }

    public synchronized void registrarCorredor(Corredor corredor) {
        this.corredores.add(corredor);
    }

    public int getTamanhoPista() {
        return this.tamanhoPista;
    }

    public synchronized List<Corredor> getCorredores() {
        return new ArrayList<>(corredores);
    }

    public synchronized void registrarPasso() {
        this.iteracao++;
        this.logCorrida.registrarIteracao(this.iteracao, this.corredores);
        
        final int iteracaoAtual = this.iteracao;
        SwingUtilities.invokeLater(() -> tela.atualizarPista(iteracaoAtual));
    }

    public synchronized void registrarChegada(Corredor corredor) {
        if (!this.podio.contains(corredor)) {
            this.podio.add(corredor);
        }
    }

    public synchronized void finalizar() {
        this.logCorrida.registrarFinalizacao(this.podio);
        final List<Corredor> resultadoFinal = new ArrayList<>(this.podio);
        SwingUtilities.invokeLater(() -> tela.exibirPodio(resultadoFinal));
    }
}