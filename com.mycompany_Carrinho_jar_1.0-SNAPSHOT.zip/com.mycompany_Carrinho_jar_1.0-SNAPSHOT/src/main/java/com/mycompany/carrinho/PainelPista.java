import javax.swing.JPanel;
import java.awt.*;
import java.util.List;

public class PainelPista extends JPanel {

    private List<Corredor> corredores;
    private int tamanhoPista = ConfiguracaoCorrida.TAMANHO_PISTA;

    private final Color[] coresCarros = {
        new Color(220, 53, 69),   // Vermelho (MIN)
        new Color(255, 193, 7),   // Amarelo (MED)
        new Color(40, 167, 69)    // Verde (MAX)
    };

    public PainelPista() {
        setBackground(new Color(45, 45, 48));
        setPreferredSize(new Dimension(800, 320));
    }

    public void setDadosCorrida(List<Corredor> corredores, int tamanhoPista) {
        this.corredores = corredores;
        this.tamanhoPista = tamanhoPista;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int largura = getWidth();
        int altura = getHeight();
        int margemEsquerda = 110;
        int margemDireita = 80;
        int larguraUtilPista = largura - margemEsquerda - margemDireita;

        // Desenha linha de largada e chegada
        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(3));
        g2.drawLine(margemEsquerda, 30, margemEsquerda, altura - 30);

        // Linha de chegada quadriculada
        int xChegada = margemEsquerda + larguraUtilPista;
        desenharLinhaChegada(g2, xChegada, 30, altura - 30);

        if (corredores == null || corredores.isEmpty()) {
            return;
        }

        int alturaFaixa = (altura - 60) / corredores.size();

        for (int i = 0; i < corredores.size(); i++) {
            Corredor c = corredores.get(i);
            int yFaixa = 30 + (i * alturaFaixa);
            int yCentro = yFaixa + (alturaFaixa / 2);

            // Faixa divisória pontilhada
            if (i > 0) {
                g2.setColor(new Color(150, 150, 150));
                float[] dash = {10.0f};
                g2.setStroke(new BasicStroke(1.5f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, dash, 0.0f));
                g2.drawLine(20, yFaixa, largura - 20, yFaixa);
            }

            // Texto identificador da raia
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("SansSerif", Font.BOLD, 13));
            g2.drawString("Carro #" + c.getIdCorredor() + " [" + c.getRotulo() + "]", 15, yCentro - 5);
            g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
            g2.setColor(Color.LIGHT_GRAY);
            g2.drawString(c.getPosicao() + " / " + tamanhoPista, 15, yCentro + 15);

            // Cálculo da posição X proporcional
            double progresso = (double) c.getPosicao() / tamanhoPista;
            int xCarro = margemEsquerda + (int) (progresso * larguraUtilPista) - 45; // -45 para o bico tocar a linha na chegada
            if (c.getPosicao() == 0) {
                xCarro = margemEsquerda - 45;
            }

            desenharCarrinho(g2, xCarro, yCentro - 15, coresCarros[i % coresCarros.length], String.valueOf(c.getIdCorredor()));
        }
    }

    private void desenharLinhaChegada(Graphics2D g2, int x, int yInicio, int yFim) {
        int tamanhoQuadrado = 8;
        boolean branco = true;
        for (int y = yInicio; y < yFim; y += tamanhoQuadrado) {
            g2.setColor(branco ? Color.WHITE : Color.BLACK);
            g2.fillRect(x, y, tamanhoQuadrado, tamanhoQuadrado);
            g2.setColor(!branco ? Color.WHITE : Color.BLACK);
            g2.fillRect(x + tamanhoQuadrado, y, tamanhoQuadrado, tamanhoQuadrado);
            branco = !branco;
        }
    }

    private void desenharCarrinho(Graphics2D g2, int x, int y, Color cor, String numero) {
        // Corpo do carro
        g2.setColor(cor);
        g2.fillRoundRect(x, y + 6, 46, 18, 8, 8);

        // Cabine / Teto
        g2.fillRoundRect(x + 8, y, 24, 12, 6, 6);

        // Janela
        g2.setColor(new Color(200, 230, 255));
        g2.fillRoundRect(x + 18, y + 2, 11, 7, 3, 3);

        // Aerofólio traseiro
        g2.setColor(cor.darker());
        g2.fillRect(x - 2, y + 2, 4, 8);

        // Rodas
        g2.setColor(Color.BLACK);
        g2.fillOval(x + 6, y + 19, 11, 11);
        g2.fillOval(x + 29, y + 19, 11, 11);

        // Calotas
        g2.setColor(Color.LIGHT_GRAY);
        g2.fillOval(x + 9, y + 22, 5, 5);
        g2.fillOval(x + 32, y + 22, 5, 5);

        // Número na porta
        g2.setColor(Color.WHITE);
        g2.setFont(new Font("SansSerif", Font.BOLD, 10));
        g2.drawString(numero, x + 13, y + 18);
    }
}