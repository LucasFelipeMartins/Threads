package com.mycompany.Pilha;

import java.util.logging.Level;
import java.util.logging.Logger;

public class PrincipalPilha {
    public static void main(String[] args) {
        Pilha pilha = new Pilha(10);

        Empilhamento emp = new Empilhamento(pilha);
        Desempilhamento desemp = new Desempilhamento(pilha);

        emp.start();
        desemp.start();

        try {
            emp.join();
            desemp.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(PrincipalPilha.class.getName()).log(Level.SEVERE, null, ex);
        }

        System.out.println("Execução da pilha finalizada!");
    }
}