package com.mycompany.Pilha;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Empilhamento extends Thread {
    private final Pilha pilha;

    public Empilhamento(Pilha pilha) {
        this.pilha = pilha;
    }

    @Override
    public void run() {
        Random random = new Random();
        for (int i = 0; i < 10; i++) {
            try {
                pilha.empilha(random.nextInt(100));
            } catch (InterruptedException ex) {
                Logger.getLogger(Empilhamento.class.getName()).log(Level.SEVERE, null, ex);
                Thread.currentThread().interrupt();
                break;
            }
        }
    }
}