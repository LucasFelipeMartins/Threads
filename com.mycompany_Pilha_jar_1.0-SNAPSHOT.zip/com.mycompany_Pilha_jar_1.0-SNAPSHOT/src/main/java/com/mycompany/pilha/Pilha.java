package com.mycompany.Pilha;

public class Pilha {
    private final int[] corpo;
    private final int max;
    private int topo;

    public Pilha(int max) {
        this.max = max;
        this.corpo = new int[max];
        this.topo = -1;
    }

    public synchronized boolean vazia() {
        return this.topo < 0;
    }

    public synchronized boolean cheia() {
        // Como o array vai de 0 até max - 1, a pilha está cheia quando topo == max - 1
        return this.topo >= this.max - 1;
    }

    public synchronized int desempilha() throws InterruptedException {
        while (vazia()) {
            System.out.println("Pilha Vazia, aguardando...");
            wait(); // espera pelo empilhamento de valores
        }
        int desempilhado = this.corpo[topo];
        System.out.println("Valor desempilhado: " + desempilhado);
        topo--;
        notify(); // acorda thread de empilhamento dormida por conta de pilha cheia
        return desempilhado;
    }

    public synchronized void empilha(int x) throws InterruptedException {
        while (cheia()) {
            System.out.println("Pilha Cheia, aguardando...");
            wait(); // espera por desempilhamento
        }
        topo++;
        this.corpo[topo] = x;
        System.out.println("Valor Empilhado: " + x);
        notify(); // acorda thread de desempilhamento dormida por conta de pilha vazia
    }
}