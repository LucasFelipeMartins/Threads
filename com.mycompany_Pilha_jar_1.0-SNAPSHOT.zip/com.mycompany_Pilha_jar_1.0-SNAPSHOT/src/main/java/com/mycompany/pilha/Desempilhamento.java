package com.mycompany.Pilha;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Desempilhamento extends Thread {
    private final Pilha pilha;

    public Desempilhamento(Pilha pilha) {
        this.pilha = pilha;
    }

    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            try {
                pilha.desempilha();
            } catch (InterruptedException ex) {
                Logger.getLogger(Desempilhamento.class.getName()).log(Level.SEVERE, null, ex);
                Thread.currentThread().interrupt();
                break;
            }
        }
    }
}