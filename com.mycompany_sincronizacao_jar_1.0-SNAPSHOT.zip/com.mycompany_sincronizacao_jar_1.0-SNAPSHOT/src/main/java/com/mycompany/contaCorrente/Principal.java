package com.mycompany.contaCorrente;

import com.mycompany.contaCorrente.ContaCorrente;
import com.mycompany.contaCorrente.Deposito;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Principal {
    public static void main(String[] args) {
        ContaCorrente conta = new ContaCorrente();

        // Passando a mesma instância de conta para ambas as threads
        Deposito threadDeposito = new Deposito(conta);
        Saque threadSaque = new Saque(conta);

        threadSaque.start();
        threadDeposito.start();

        try {
            threadDeposito.join(); // aguarda todos os depósitos terminarem
        } catch (InterruptedException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }

        // Se a thread de saque ainda estiver esperando saldo após o fim dos depósitos, encerra
        if (threadSaque.isAlive() && !threadSaque.isInterrupted()) {
            threadSaque.interrupt();
        }

        System.out.println("Execução finalizada. Saldo final: R$" + conta.getSaldo());
    }
}