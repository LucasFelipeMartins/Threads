package com.mycompany.contaCorrente;

public class ContaCorrente {
    private float saldo;

    public ContaCorrente() {
        this.saldo = 0;
    }

    public synchronized float getSaldo() {
        return this.saldo;
    }

    public synchronized void saque(float valor) throws InterruptedException {
        if (this.saldo < valor) {
            System.out.println("Saldo Insuficiente para sacar R$" + valor);
            System.out.println("Saldo atual: R$" + this.saldo + " (aguardando depósito...)");
            wait(); // suspende a thread até que um depósito ocorra
        } else {
            this.saldo -= valor;
            System.out.println("Sacado: R$" + valor + " | Saldo: R$" + this.saldo);
        }
    }

    public synchronized void deposito(float valor) {
        this.saldo += valor;
        System.out.println("Depositado: R$" + valor + " | Saldo: R$" + this.saldo);
        notify(); // acorda a thread de saque que estiver em wait()
    }
}