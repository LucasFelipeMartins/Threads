package com.mycompany.contaCorrente;

import java.util.Random;

public class Deposito extends Thread {
    private final ContaCorrente conta;

    public Deposito(ContaCorrente conta) {
        this.conta = conta;
    }

    @Override
    public void run() {
        Random r = new Random();
        for (int i = 0; i < 10; i++) {
            conta.deposito(r.nextInt(100));
        }
    }
}