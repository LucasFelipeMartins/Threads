package com.mycompany.contaCorrente;

import com.mycompany.contaCorrente.ContaCorrente;
import java.util.Random;

public class Saque extends Thread {
    private final ContaCorrente conta;

    public Saque(ContaCorrente conta) {
        this.conta = conta;
    }

    @Override
    public void run() {
        Random r = new Random();
        for (int i = 0; i < 10; i++) {
            try {
                conta.saque(r.nextInt(100));
            } catch (InterruptedException ex) {
                System.out.println("Thread de saque interrompida por falta de saldo!");
                break; // encerra o laço com segurança
            }
        }
    }
}